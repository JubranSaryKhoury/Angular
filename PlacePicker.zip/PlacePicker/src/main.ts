import { bootstrapApplication } from '@angular/platform-browser';

import { AppComponent } from './app/app.component';
import {
  HttpClient,
  HttpEventType,
  HttpHandler,
  HttpHandlerFn,
  HttpRequest,
  provideHttpClient,
  withInterceptors,
} from '@angular/common/http';
import { tap } from 'rxjs';

// important notes
// as usual run npm istall.. and also run npm install inside backend file
// cd backend
// npm istall
// and also npm start ... in order to start the backend API
// then filanlly --> new terminal --> npm start

function loggingInterceptors(
  request: HttpRequest<unknown>,
  next: HttpHandlerFn
) {
  // // clone method is used to change parts of the request (like body,headers,...)
  // const req = request.clone({
  //   // for example change the headrers (set the 'X-DEBUG' to 'TESTING')
  //   headers: request.headers.set('X-DEBUG', 'TESTING'),
  // });
  console.log('[Outgoing request]');
  console.log(request);
  return next(request).pipe(
    tap({
      // here tab instead of subscribe

      next: (event) => {
        if (event.type === HttpEventType.Response) {
          console.log('[Incoming response]');
          console.log(event.status);
          console.log(event.body);
        }
      },
    })
  );
}
bootstrapApplication(AppComponent, {
  // here for example the function 'loggingInterceptors' are not excuted (like this loggingInterceptors()) ... but pass it
  providers: [provideHttpClient(withInterceptors([loggingInterceptors]))],
}).catch((err) => console.error(err));
