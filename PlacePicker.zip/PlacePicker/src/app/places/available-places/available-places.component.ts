import { Component, signal, inject, OnInit, DestroyRef } from '@angular/core';

import { Place } from '../place.model';
import { PlacesComponent } from '../places.component';
import { PlacesContainerComponent } from '../places-container/places-container.component';
//import { HttpClient } from '@angular/common/http';
import { PlacesService } from '../places.service';
//import { catchError, map, throwError } from 'rxjs';

@Component({
  selector: 'app-available-places',
  standalone: true,
  templateUrl: './available-places.component.html',
  styleUrl: './available-places.component.css',
  imports: [PlacesComponent, PlacesContainerComponent],
})
export class AvailablePlacesComponent implements OnInit {
  isFetching = signal(false); // just for display text on the screen while fetching the data (for example, Loading availabe places...)

  error = signal('');

  places = signal<Place[] | undefined>(undefined);

  // private httpClient = inject(HttpClient); // inject the service or alternativelly by  using the constructor as shown below
  // //constructor(private httpClient:HttpClient){}

  private placeService = inject(PlacesService);

  private destroyRef = inject(DestroyRef); // in order to unsubscribe

  // I need to  fetch the data from the backend(or the database) right at the start when this component becomes available
  ngOnInit() {
    this.isFetching.set(true);

    // this sends a get request (get method take the url to which send the request ... note that localhost:3000 is the pre-prepared  domain of that dummy backend). because its return observale then we need to subscribe ... if you just create an observable without subcribe then its worth nothing (or its do nothing) so you need to subscribe to trigger that request
    const subscription = this.placeService.loadAvailablePlaces().subscribe({
      next: (places) => {
        //console.log(resData.places);
        this.places.set(places);
      },
      error: (error: Error) => {
        this.error.set(error.message);
      },
      complete: () => {
        this.isFetching.set(false);
      },
    });
    this.destroyRef.onDestroy(() => {
      subscription.unsubscribe();
    });
  }

  onSelectPlace(selectedPlace: Place) {
    const subscription = this.placeService
      .addPlaceToUserPlaces(selectedPlace)
      .subscribe({
        next: (resData) => console.log(resData),
      });
    this.destroyRef.onDestroy(() => {
      subscription.unsubscribe();
    });
  }
}
