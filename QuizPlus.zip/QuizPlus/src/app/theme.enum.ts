export enum theme {
  DARK = 'Dark',
  LIGHT = 'Light',
}
