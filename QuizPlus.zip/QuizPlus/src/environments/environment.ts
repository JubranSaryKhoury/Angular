export const environment = {
  firebase: {
    apiKey: 'AIzaSyAcMiSuyx1QB7SZxY-_uD3_OP-Bv3JfjfA',
    authDomain: 'quizpluschatbot.firebaseapp.com',
    projectId: 'quizpluschatbot',
    storageBucket: 'quizpluschatbot.appspot.com',
    messagingSenderId: '829903529416',
    appId: '1:829903529416:web:4f7bb7f9f8c4b1303f0cfd',
  },
  production: false,
};
